# Test plugin z3r01 designed for testing the zcore plugin system

# imports here ---------------------------------------------------------------------------------------------------------
import asyncio  # Required
import funkenstein as func
import sys_zcore as pc

# declare data map
pdata = {}

# zcore plugin initialize [*REQUIRED FUNCTION*] -----------------------------------------------------------------------
# this assigns and builds the data map for the plugin (called from zcore on start up)

def plugin_init_():
    global pdata  # always call this first from every function

    # -[ Plugin Title ]-------------------------------------------------------------------------------------------------
    pdata['ptitle'] = 'Test Plugin 01'  # title of plugin (anything)
    pdata['pversion'] = 'z3r01'  # version (anything)
    pdata['pauthor'] = 'Neo Nemesis'  # who wrote it
    pdata['mreqver'] = '0.1x'

    # -[ Assign Data from test_plugin.cnf ] ----------------------------------------------------------------------------

    pdata['moduleprint'] = True  # Does this module print to data stream? True or False --> see mprint()
    # pdata['modulelog'] = False  # Does this module print data to a file? True or False --> see mprint()

    # serverlist
    pdata['serverlist'] = func.cnfread('test_plugin.cnf', 'test', 'serverlist').lower()

    # split up into each server
    pdata['server'] = pdata['serverlist'].split(',')

    # run thru the list for server and channel specific data
    for x in range(len(pdata['server'])):
        server = pdata['server'][x]
        # assign channels
        # pdata['servername', 'channels'] = #channel1,#channel2,etc
        pdata[server, 'channels'] = func.cnfread('test_plugin.cnf', server, 'channels')

        # split up into each channel
        # pdata['servername', 'channel'][x] = #channelx
        pdata[server, 'channel'] = pdata[server, 'channels'].split(',')
        continue

    # data map complete
    mprint(f'{pdata['ptitle']} * Version: {pdata['pversion']} By: {pdata['pauthor']} - Loaded successfully.')

# STDOUT printing [*REQUIRED FUNCTION*]---------------------------------------------------------------------------------
# For module printing use this instead of print()
# function name 'tprint' can be anything you define
# set to False above to disable
def mprint(string):
    global pdata  # always call this first from every function

    # printing to STDOUT
    if pdata['moduleprint'] is True:
        print(f'[TEST_MODULE] * {string}')  # This can be print(f'{string}') or print(f'Anything: {string}')

    # logging to file
    # if pdata['modulelog'] is True:
        # write data to file
    return
# <-- End tprint() -----------------------------------------------------------------------------------------------------

# EVENTS ---------------------------------------------------------------------------------------------------------------
# evt_privmsg('servername', b':Username!~Host@mask.net PRIVMSG target :Message data')
# PRIVMSG
async def evt_privmsg(server, message):
    global pdata  # always call this first from every function

    # split up the message into single words
    mdata = message.split(b' ')
    channel = mdata[2]

    # keep data case lower
    if mdata[3].lower() == b':!ptest':
        pc.privmsg_(server, channel, 'Testing 1 2 3')
