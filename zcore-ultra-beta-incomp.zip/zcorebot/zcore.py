#! /usr/bin/python3
# Mode60
# ======================================================================================================================
# Title.............: 'zcore'
# Filename..........: zcore.py (main file)
# Version...........: 0.1x
# Author............: Neo Nemesis
# Description.......: Expandable, scriptable, modular and most importantly, customizable IRC Bot core.
#                     Multi-network/channel. Can load and run python modules [that are designed to run with this core].
#                     See sys_zcore.py for working example of a 'zcore System Module'
#                     visit website for more info on zcore plugins
# Python Version....: 3.12.0
# Bot Files List....: zcore.py, sys_zcore.py, funkenstein.py, zcore.cnf
# ----------------------------------------------------------------------------------------------------------------------
# Imports...........: funkenstein.py is required and supplied with zcore (not included with python install.)
import socket
import ssl
import platform
import time
import threading
import asyncio
import os.path
import funkenstein as func
# ----------------------------------------------------------------------------------------------------------------------
# Global data map
zcore = {}
# ======================================================================================================================
# start_up()
# Main start up function. Builds data map from zcore.cnf and initiates network threads and starts main loop.
async def start_up():
    global zcore
    # start up process, building data map
    print(f'[*] START UP * Powered by zcore (System Info: python: version {platform.python_version()} - OpenSSL: {ssl.OPENSSL_VERSION})')
    # check to make sure zcore.cnf exists
    if os.path.isfile('./zcore.cnf') is False:
        print(f'[*] ERROR * Required system file "zcore.cnf" is not found in zcore directory. Shutting down...')
        exit()
    # python version check needed here ?
    # ------------------------------------------------------------------------------------------------------------------
    # this below is the bot's core data [zcore] -> zcore.cnf used across all threads
    # to change this data go to zcore.cnf [zcore]
    zcore['serverlist'] = func.cnfread('zcore.cnf', 'zcore', 'serverlist').lower()
    zcore['botmaster'] = func.cnfread('zcore.cnf', 'zcore', 'botmaster').lower()
    # zcore['botadmin'] = func.cnfread('zcore.cnf', 'zcore', 'botadmin').lower()
    zcore['pingtime'] = int(func.cnfread('zcore.cnf', 'zcore', 'pingtime'))
    zcore['sysmod'] = func.cnfread('zcore.cnf', 'zcore', 'system').lower()
    zcore['plugins'] = func.cnfread('zcore.cnf', 'zcore', 'plugins').lower()
    zcore['plugin'] = zcore['plugins'].split(',')
    # ------------------------------------------========================================================================
    # MAIN PLUGIN CONTROL (no plugmods = False)
    zcore['plugmods'] = True
    # =======================================---------------------------------------------------------------------------
    # global use data (do not alter)
    zcore['keepalive'] = False
    zcore['sslref'] = ''
    zcore['mode'] = 'start'
    zcore['dump'] = ''
    # version hard code do not change ----------------------------------------------------------------------------------
    # zcore module failure/errors will occur!
    zcore['version'] = '0.1x'
    zcore['versionid'] = 'PYC0R3V01X'
    print(f'[*] RUNNING * zcore version: {zcore['version']} by Neo Nemesis')
    # ------------------------------------------------------------------------------------------------------------------
    # Loading system module (if specified in zcore.cnf: [zcore] > system = modulename
    # ONLY 1 SYSTEM MODULE.
    # If no system module is being used, then zcore.cnf: [zcore] > system = 0
    # ------------------------------------------------------------------------------------------------------------------
    # No system module specified
    if zcore['sysmod'] == '0':
        zcore['system'] = '0'
        print(f'[*] No system module specified. Internal system disabled.')
    # ------------------------------------------------------------------------------------------------------------------
    # System module specified
    else:
        print(f'[*] Checking for system module {zcore['sysmod']}...')
        time.sleep(0.5)  # sure does
        # module filename.py exists
        if os.path.isfile('./' + zcore['sysmod'] + '.py') is True:
            print(f'[*] System Module found. Loading...')
            zcore['system'] = __import__(zcore['sysmod'])
            try:
                zcore['system'].system_init_(zcore['version'])
            except AttributeError:
                zcore['system'] = '0'
                print(f'[*] ERROR * Module failed to load: {zcore['sysmod']} is not recognized as a system module. System mode disabled.')
        # module filename.py does not exist
        else:
            zcore['system'] = '0'  # zcore['system'] = 'err1'  system module filename.py is missing
            print(f'[*] ERROR * System module {zcore['sysmod']}.py is not found. System mode disabled.')
    # ------------------------------------------------------------------------------------------------------------------
    # check for and load plugins
    # ------------------------------------------------------------------------------------------------------------------
    if zcore['plugins'] == '0':
        print(f'[*] 0 plugin modules specified. Plugin system disabled.')
        if zcore['system'] == '0':
            print(f'[*] Running in idle mode')
    else:
        print(f'[*] {len(zcore['plugin'])} plugin module(s) found.')
        plugint = zcore['plugins'].split(',')
        time.sleep(0.5)
        for x in range(len(zcore['plugin'])):
            if os.path.isfile('./' + zcore['plugin'][x] + '.py') is True:
                print(f'[*] Attempting to load: {zcore['plugin'][x]}')
                zcore['plugin'][x] = __import__(zcore['plugin'][x])
                try:
                    zcore['plugin'][x].plugin_init_()
                except AttributeError:
                    print(f'[*] ERROR * Plugin module {plugint[x]} is not recognized as a plugin module.')
                    zcore['plugin'][x] = '0'
            else:
                print(f'[*] ERROR * Plugin module {plugint[x]}.py is not found.')
                zcore['plugin'][x] = '0'
            continue

    # ------------------------------------------------------------------------------------------------------------------
    # start up IRC connections
    # ------------------------------------------------------------------------------------------------------------------
    # this data pertains to each network specifically. [serverid] -> zcore.cnf
    print(f'[*] Preparing to connect to IRC network(s)...')
    time.sleep(1.5)  # not sure if really needed?
    p_server = zcore['serverlist'].split(',')
    for x in range(len(p_server)):
        # each server (p_server[x]=serverid) in zcore.cnf ([zcore]>serverlist) gets its own map and network thread
        # zcore['serverid', 'data']
        zcore[p_server[x], 'serverid'] = func.cnfread('zcore.cnf', p_server[x], 'serverid').lower()
        zcore[p_server[x], 'serveraddr'] = func.cnfread('zcore.cnf', p_server[x], 'serveraddr').lower()
        zcore[p_server[x], 'serverport'] = int(func.cnfread('zcore.cnf', p_server[x], 'serverport'))
        zcore[p_server[x], 'serverssl'] = func.cnfread('zcore.cnf', p_server[x], 'serverssl').lower()
        zcore[p_server[x], 'botname'] = func.cnfread('zcore.cnf', p_server[x], 'botname')
        zcore[p_server[x], 'botpass'] = func.cnfread('zcore.cnf', p_server[x], 'botpass')
        zcore[p_server[x], 'channels'] = func.cnfread('zcore.cnf', p_server[x], 'channels').lower()
        zcore[p_server[x], 'keepalive'] = time.time()
        zcore[p_server[x], 'connected'] = False
        zcore[p_server[x], 'lastlag'] = 'NA'
        # start network thread
        zcore[p_server[x], 'thread'] = threading.Thread(target=irc_connect, args=(p_server[x],), daemon=True)
        zcore[p_server[x], 'thread'].start()
        continue
    # ------------------------------------------------------------------------------------------------------------------
    # starts the main 'keep alive' loop when the above is finished
    await keep_alive()
# <-- End start_up() ===================================================================================================

# ======================================================================================================================
# irc_connect(serverid)
# Connection and loop start up procedure for specified network thread (serverid)
def irc_connect(serverid):
    global zcore
    print(f'[*] Opening connection to {serverid}...')
    # socket start up and connect
    zcore[serverid, 'sock'] = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    zcore[serverid, 'sock'].connect((str(zcore[serverid, 'serveraddr']), int(zcore[serverid, 'serverport'])))
    # SSL only
    if zcore[serverid, 'serverssl'] == 'yes':
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        zcore[serverid, 'sock'] = context.wrap_socket(zcore[serverid, 'sock'], server_hostname=zcore[serverid, 'serveraddr'])
    # Send USER, NICK and (optional) PASS to server.
    zcore[serverid, 'sock'].send(b'USER ' + bytes(str(zcore[serverid, 'botname']), 'utf-8') + b' zCore zCore :zCore (ZeroOne) ' + bytes(str(zcore['version']), 'utf-8') + b'\r\n')
    zcore[serverid, 'sock'].send(b'NICK ' + bytes(str(zcore[serverid, 'botname']), 'utf-8') + b'\r\n')
    if zcore[serverid, 'botpass'] != '0':
        zcore[serverid, 'sock'].send(b'PASS ' + bytes(str(zcore[serverid, 'botpass']), 'utf-8') + b'\r\n')
    # starts the socket loop in the network thread.
    zcore[serverid, 'connected'] = 'Try'
    asyncio.run(irc_loop(serverid))
# <-- End irc_connect() ================================================================================================

# ======================================================================================================================
# irc_loop(threadname)
# asyncio irc socket loop (runs in each network thread)
async def irc_loop(threadname):
    global zcore
    while 1:
        if zcore['mode'] == 'shutdown' or zcore['mode'] == 'reboot' or zcore[threadname, 'connected'] is False:
            break
        # check if keep alive is still keeping alive
        if not zcore['keepalive']:
            await keep_alive()
        # --------------------------------------------------------------------------------------------------------------
        # main socket data receiving
        # because for some reason certain server SSL patterns cause random EOF (see exception at bottom of loop)
        zcore[threadname, 'recv'] = zcore[threadname, 'sock'].recv(2040)  # receiving
        zcore[threadname, 'data_line'] = zcore[threadname, 'recv'].splitlines()  # separation
        # parse socket data
        for x in range(len(zcore[threadname, 'data_line'])):
            zcore[threadname, 'data'] = zcore[threadname, 'data_line'][x].split(b' ')
            if len(zcore[threadname, 'data']) > 1:
                # --------------------------------------------------------------------------------------------------
                # server ping/pong and lag timer
                # received ping from server, send pong reply
                if zcore[threadname, 'data'][0] == b'PING':
                    zcore[threadname, 'keepalive'] = time.time()
                    print(f'[*] {threadname} ---> Ping? {zcore[threadname, 'data'][1]}')
                    zcore[threadname, 'sock'].send(b'PONG ' + zcore[threadname, 'data'][1] + b'\r\n')
                    print(f'[*] {zcore[threadname, 'botname']} ---> {threadname} Pong! {zcore[threadname, 'data'][1]}')
                    continue
                # received pong reply from ping sent to server
                # keep alive pong and lag timer
                if zcore[threadname, 'data'][1] == b'PONG':
                    zcore['keepalive', 'math'] = round(time.time() - zcore[threadname, 'keepalive'], 2)
                    zcore[threadname, 'lastlag'] = zcore['keepalive', 'math']
                    print(f'[*] {threadname} ---> PONG (KeepAlive) Lag: {zcore['keepalive', 'math']} seconds')
                    continue
                # --------------------------------------------------------------------------------------------------
                # connection successful, raw 001 welcome message
                if zcore[threadname, 'data'][1] == b'001':
                    print(f'[*] {threadname} connection successful.')
                    # send socket data to system module and/or plugins
                    socket_transfer(threadname, zcore[threadname, 'sock'])
                    zcore[threadname, 'connected'] = True
                    # join channels
                    zcore[threadname, 'chan'] = zcore[threadname, 'channels'].split(',')
                    for y in range(len(zcore[threadname, 'chan'])):
                        print(f'[*] {threadname} joining {zcore[threadname, 'chan'][y]}...')
                        zcore[threadname, 'sock'].send(b'JOIN ' + bytes(str(zcore[threadname, 'chan'][y]), 'utf-8') + b'\r\n')
                        continue
                    continue
                # ------------------------------------------------------------------------------------------------------
                # PRIVMSG handling (also CTCP)
                if len(zcore[threadname, 'data']) > 2:
                    # --------------------------------------------------------------------------------------------------
                    # failsafe prints data to screen if no modules or plugins are loaded
                    if zcore['plugins'] == '0' and zcore['system'] == '0':
                        print(f'[*] {threadname} ---> {zcore[threadname, 'data_line'][x]}')
                    # --------------------------------------------------------------------------------------------------
                    if zcore[threadname, 'data'][1] == b'PRIVMSG':
                        # PRIVMSG :\x01 (CTCP)
                        # CTCP Version
                        zcore[threadname, 'rusername'] = b''
                        if zcore[threadname, 'data'][3].upper() == b':\x01VERSION\x01':
                            zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                            print(f'[*] {threadname} * {zcore[threadname, 'rusername'].decode()} ---> CTCP VERSION REQUEST')
                            zcore[threadname, 'sock'].send(b'NOTICE ' + zcore[threadname, 'rusername'] + b' :\x01VERSION zCore (ZeroOne) version ' + bytes(str(zcore['version']), 'utf-8') + b' (Running: ' + bytes(str(zcore['versionid']), 'utf-8') + b')\x01\r\n')
                            continue
                        # CTCP Finger
                        if zcore[threadname, 'data'][3].upper() == b':\x01FINGER\x01':
                            zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                            print(f'[*] {threadname} * {zcore[threadname, 'rusername'].decode()} ---> CTCP FINGER REQUEST')
                            zcore[threadname, 'sock'].send(b'NOTICE ' + zcore[threadname, 'rusername'] + b' :\x01FINGER zCore (ZeroOne) version ' + bytes(str(zcore['version']), 'utf-8') + b' (Running: ' + bytes(str(zcore['versionid']), 'utf-8') + b')\x01\r\n')
                            continue
                        # CTCP vid (zcore only)
                        if zcore[threadname, 'data'][3].upper() == b':\x01VERSIONID\x01' or zcore[threadname, 'data'][3].upper() == b':\x01VID\x01':
                            zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                            print(f'[*] {threadname} * {zcore[threadname, 'rusername'].decode()} ---> zcore VERSIONID REQUEST [VID]')
                            zcore[threadname, 'sock'].send(b'NOTICE ' + zcore[threadname, 'rusername'] + b' :\x01VERSION zCore (ZeroOne)' + bytes(str(zcore['version']), 'utf-8') + b' by Neo Nemesis (C) Mode60 2024 - ' + bytes(str(zcore['versionid']), 'utf-8') + b' is powered by zCore a GNU 3.0 licensed FOSS python modular IRC bot core.\x01\r\n')
                            continue
                        # CTCP Ping
                        if zcore[threadname, 'data'][3].upper() == b':\x01PING':
                            zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                            print(f'[*] {threadname} * {zcore[threadname, 'rusername'].decode()} ---> CTCP PING {zcore[threadname, 'data'][4].decode()}')
                            zcore[threadname, 'sock'].send(b'NOTICE ' + zcore[threadname, 'rusername'] + b' :\x01PING ' + zcore[threadname, 'data'][4] + b'\r\n')
                            continue
                        # ----------------------------------------------------------------------------------------------
                        # BotMaster core commands
                        zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                        zcore[threadname, 'dusername'] = zcore[threadname, 'rusername'].decode()
                        if zcore[threadname, 'dusername'].lower() in zcore['botmaster']:
                            # ------------------------------------------------------------------------------------------
                            # Botmaster Channel Commands
                            if b'#' in zcore[threadname, 'data'][2]:
                                # !shutdown
                                if zcore[threadname, 'data'][3].lower() == b':!shutdown':
                                    print(f'[*] Shutdown command issued by: {zcore[threadname, 'rusername']}')
                                    shut_down()
                                    break
                                # !restart
                                if zcore[threadname, 'data'][3].lower() == b':!restart' or zcore[threadname, 'data'][3].lower() == b':!reboot':
                                    print(f'[*] Reboot command issued by: {zcore[threadname, 'rusername']}')
                                    re_start()
                                    break
                                # !test (disable before release)
                                if zcore[threadname, 'data'][3] == b':!test':
                                    zcore[threadname, 'sock'].send(b'PRIVMSG ' + zcore[threadname, 'data'][2] + b' :Testing 1 2 3!\r\n')
                                    continue
                            # ------------------------------------------------------------------------------------------
                            # Botmaster /privmsg commands
                            if b'#' not in zcore[threadname, 'data'][2]:
                                if zcore[threadname, 'data'][3].lower() == b':stats':
                                    zcore[threadname, 'rusername'] = func.gettok(zcore[threadname, 'data'][0], 0, b'!').replace(b':', b'')
                                    zcore[threadname, 'rusername'] = zcore[threadname, 'rusername'].decode()
                                    zcore[threadname, 'rusername'] = zcore[threadname, 'rusername'].lower()
                                    if zcore[threadname, 'rusername'] in zcore['botmaster']:
                                        await stats_msg(threadname, zcore[threadname, 'rusername'])
                                    continue
                    # --------------------------------------------------------------------------------------------------
                    # send privmsg data thru system module and plugins
                        # ----------------------------------------------------------------------------------------------
                        # ACTION
                        if zcore[threadname, 'data'][3] == b':\x01ACTION':
                            # run data in system module
                            if zcore['system'] != '0':
                                # Determine if exct_ function is defined
                                try:
                                    await zcore['system'].exct_action(threadname, zcore[threadname, 'data_line'][x])
                                except AttributeError:
                                    zcore['dump'] = '0'  # Surely this is needed.
                            # run data in plugin module(s)
                            if zcore['plugins'] != '0':
                                for p in range(len(zcore['plugin'])):
                                    if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                        print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                        continue
                                    elif zcore['plugin'][p] != 'err':
                                        try:
                                            await zcore['plugin'][p].evt_action(threadname, zcore[threadname, 'data_line'][x])
                                        except AttributeError:
                                            zcore['dump'] = '0'  # Of course
                                    continue
                            continue
                        # ----------------------------------------------------------------------------------------------
                        # PRIVMSG
                        else:
                            # run data in system module
                            if zcore['system'] != '0':
                                try:
                                    await zcore['system'].exct_privmsg(threadname, zcore[threadname, 'data_line'][x])
                                except AttributeError:
                                    zcore['dump'] = '0'  # Yep, is it faster?
                            # run data in plugin module(s)
                            if zcore['plugins'] != '0':
                                for p in range(len(zcore['plugin'])):
                                    if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                        print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                        continue
                                    else:
                                        try:
                                            await zcore['plugin'][p].evt_privmsg(threadname, zcore[threadname, 'data_line'][x])
                                        except AttributeError:
                                            zcore['dump'] = '0'  # Of course
                                    continue
                            continue
                    # ------------------------------------------------------------------------------------------------------
                    # NOTICE handling
                    if zcore[threadname, 'data'][1] == b'NOTICE':
                        # run data in system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_notice(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # sure
                        # run data in plugin module(s)
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_notice(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue
                        continue
                    # --------------------------------------------------------------------------------------------------
                    # JOIN handling
                    if zcore[threadname, 'data'][1] == b'JOIN':
                        # run data in system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_join(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # experimental
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_join(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue
                        continue
                    # --------------------------------------------------------------------------------------------------
                    # PART handling
                    if zcore[threadname, 'data'][1] == b'PART':
                        # run data in system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_part(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # experimental
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_part(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue
                        continue
                    # --------------------------------------------------------------------------------------------------
                    # KICK handling
                    # b':Neo_Nemesis!~TheOne@th3.m4tr1x.h4ck3d.y0u KICK #testduck zcore :testing 1 2 3'
                    if zcore[threadname, 'data'][1] == b'KICK':
                        # system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_kick(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # hmm
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_kick(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # MODE handling
                    # User mode +v +o etc: b':Neo_Nemesis!~TheOne@hostmask.net MODE #TestWookie +v zcore'
                    # Channel mode +i, +s etc: b':Neo_Nemesis!~TheOne@hostmask.net MODE #TestWookie +i '
                    # Channel ban +b: b':Neo_Nemesis!~TheOne@hostmask.net MODE #TestWookie +b *!*@Test'
                    if zcore[threadname, 'data'][1] == b'MODE':
                        # system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_mode(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # surely this has caught on by now
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_action(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # TOPIC handling
                    # b':Neo_Nemesis!~TheOne@hostmask.net TOPIC #TestWookie :test'
                    if zcore[threadname, 'data'][1] == b'TOPIC':
                        # system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_topic(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_topic(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # NICK changes
                    # b':Testing!Mibbit@hostmask.net NICK :Test123'
                    if zcore[threadname, 'data'][1] == b'NICK':
                        # system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_nick(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_nick(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # QUIT handling
                    # b':Test123!Mibbit@hostmask.net QUIT :Client Quit'
                    if zcore[threadname, 'data'][1] == b'QUIT':
                        # system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_quit(threadname, zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_quit(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # RAW numeric data
                    rawdata = zcore[threadname, 'data'][1].decode()
                    if rawdata.isnumeric() is True:
                        # run data in system module
                        if zcore['system'] != '0':
                            try:
                                await zcore['system'].exct_raw(threadname, zcore[threadname, 'data'][1], zcore[threadname, 'data_line'][x])
                            except AttributeError:
                                zcore['dump'] = '0'  # Still working?
                            continue
                        if zcore['plugins'] != '0':
                            for p in range(len(zcore['plugin'])):
                                if zcore['plugin'][p] == 'err' or zcore['plugin'][p] == '0':
                                    print(f'[*] ERROR * Plugin failure: {zcore['plugin'][p]}')
                                    continue
                                elif zcore['plugin'][p] != 'err':
                                    try:
                                        await zcore['plugin'][p].evt_raw(threadname, zcore[threadname, 'data_line'][x])
                                    except AttributeError:
                                        zcore['dump'] = '0'  # Of course
                                continue

                    # --------------------------------------------------------------------------------------------------
                    # Checking for broken lines and data errors in recv data from server
                    # system module only
                    if zcore['system'] != '0':
                        try:
                            await zcore['system'].exct_chk(threadname, zcore[threadname, 'data_line'][x])
                        except AttributeError:
                            zcore['dump'] = '0'  # yea
                        finally:
                            continue

                # ------------------------------------------------------------------------------------------------------
                # failsafe prints data to screen if no modules or plugins are loaded
                # if zcore['plugins'] == '0' and zcore['system'] == '0' and len(zcore[threadname, 'data']) > 2:
                #    print(f'[*] {threadname} ---> {zcore[threadname, 'data_line'][x]}')
                continue
        continue
    # ------------------------------------------------------------------------------------------------------------------
    # loop is only broken by exiting or connection loss, return will terminate thread for restarting
    if zcore['mode'] != 'shutdown' and zcore['mode'] != 'reboot':
        print(f'[*] ERROR * {threadname} connection lost.')
        zcore[threadname, 'connected'] = False
        zcore[threadname, 'sock'].close()
    return
# <-- End irc_loop() ===================================================================================================

# ======================================================================================================================
# keep_alive()
# keeps program and IRC connections alive (i.e. this is a main loop)
async def keep_alive():
    global zcore
    zcore['keepalive'] = True
    server = zcore['serverlist'].split(',')
    zcore['sslref'] = time.time()
    # ------------------------------------------------------------------------------------------------------------------
    # main loop
    while 1:
        time.sleep(0.10)  # quick break then back to work
        if zcore['mode'] == 'shutdown' or zcore['mode'] == 'reboot':
            break
        for pc in range(len(server)):
            # ----------------------------------------------------------------------------------------------------------
            # determines if any of the network threads need to be pinged.
            if round(time.time() - zcore[server[pc], 'keepalive']) >= zcore['pingtime']:
                if zcore[server[pc], 'connected'] is True or zcore[server[pc], 'connected'] == 'Try':
                    # as above in irc_loop() this is for random SSL EOF error handling (See exception below)
                    print(f'[*] {zcore[server[pc], 'botname']} ---> {server[pc]} PING (KeepAlive)')
                    zcore[server[pc], 'sock'].send(b'PING :' + bytes(str(zcore['versionid'].upper()), 'utf-8') + b'\r\n')
                    zcore[server[pc], 'keepalive'] = time.time()
                continue
        continue
    # Loop end/exit ----------------------------------------------------------------------------------------------------
    zcore['keepalive'] = False
    if zcore['mode'] == 'reboot':
        await start_up()
    if zcore['mode'] == 'shutdown':
        exit()
# <-- End keep_alive() =================================================================================================

# ======================================================================================================================
# socket_transfer(threadname, sock)
# transfers socket data to system module and/or plugins on init
def socket_transfer(threadname, sock):
    global zcore
    # system module
    if zcore['system'] != '0':
        zcore['system'].socket_stage(threadname, sock)
    # plugins
    # if zcore['plugins'] != '0':
    #    for p in range(len(zcore['plugin'])):
    #        if zcore['plugin'][p] != 'err':
    #            zcore['plugin'][p].socket_set(threadname, sock)
    #        continue

# ======================================================================================================================
# stats_msg(threadname, user)
# sends bot stats to user on threadname (BOTMASTER ONLY)
async def stats_msg(threadname, user):
    # ------------------------------------------------------------------------------------------------------------------
    # Assembling [zcore] info
    vr, vi, mm = zcore['version'], zcore['versionid'], zcore['mode']
    vr, vi, mm = 'Version: ' + vr, 'vID: ' + vi, 'Mode: ' + mm
    # [Python version: 3.12.0]
    pv = '[Python version: ' + platform.python_version() + ']'
    # [OpenSSL version]
    sl = '[' + ssl.OPENSSL_VERSION + ']'
    vs = '[zcore] ' + vr + ' | ' + vi + ' | ' + mm + ' ' + pv + ' ' + sl
    vs = vs.encode()
    # ------------------------------------------------------------------------------------------------------------------
    # [Network Data] server1id Lag: x.xx seconds | server2id Lag: x.xx seconds
    p_server = zcore['serverlist'].split(',')
    pl = ''
    for x in range(len(p_server)):
        if pl == '':
            pl = p_server[x] + ' Lag: ' + str(zcore[p_server[x], 'lastlag']) + ' seconds'
            continue
        else:
            pl = pl + ' | ' + p_server[x] + ' Lag: ' + str(zcore[p_server[x], 'lastlag']) + ' seconds'
            continue
    pl = '[Network Data] ' + pl
    pl = pl.encode()
    # ------------------------------------------------------------------------------------------------------------------
    # send the info to user
    ur = user.encode()
    zcore[threadname, 'sock'].send(b'NOTICE ' + ur + b' :' + vs + b'\r\n')
    zcore[threadname, 'sock'].send(b'NOTICE ' + ur + b' :' + pl + b'\r\n')
# <- End stats_msg() ===================================================================================================

# ======================================================================================================================
# shut_down()
# shuts down the bot and awaits for the main loop to exit
def shut_down():
    global zcore
    zcore['mode'] = 'shutdown'
    print(f'[*] Shutting down...')
    time.sleep(0.5)  # probably needed
    p_server = zcore['serverlist'].split(',')
    for x in range(len(p_server)):
        zcore[p_server[x], 'connected'] = False
        zcore[p_server[x], 'sock'].send(b'QUIT :(Powered by zcore)\r\n')
        zcore[p_server[x], 'sock'].close()
        continue
# <- End shut_down() ===================================================================================================

# ======================================================================================================================
# re_start()
# disconnects from any connected networks and prepares for reboot from main loop.
def re_start():
    global zcore
    zcore['mode'] = 'reboot'
    print(f'[*] Rebooting...')
    time.sleep(0.5)  # needed? maybe...
    p_server = zcore['serverlist'].split(',')
    for x in range(len(p_server)):
        if zcore[p_server[x], 'connected'] is True or zcore[p_server[x], 'connected'] == 'Try':
            zcore[p_server[x], 'connected'] = False
            zcore[p_server[x], 'sock'].send(b'QUIT :Bot rebooting (Powered by zcore)\r\n')
        continue
    time.sleep(0.5)  # Definitely needed...
# <- End re_start() ====================================================================================================

# ======================================================================================================================
# plugin_load_(spec)
# spec = init_load
# subject to change or be re-written
# checks zcore.cnf for listed modules and loads them performing the module plugin_init()
# planning to expand this to include more module handling than just 'init_load'
async def plugin_load_(spec):
    global zcore
    # ------------------------------------------------------------------------------------------------------------------
    # plug_mod('init_load')
    # initiate module check and load at start up only.
    if spec == 'init_load':
        time.sleep(0.75)  # just do it
        for x in range(len(zcore['plugin'])):
            # ------------------------------------------------------------------------------------------------------
            # verify that filename.py for plugin exists in script directory
            print(f'[*] Searching for plugin module: {zcore['plugin'][x]}...')
            # ------------------------------------------------------------------------------------------------------
            # file exists
            if os.path.isfile('./' + zcore['plugin'][x].lower() + '.py') is True:
                print(f'[*] Found {zcore['plugin'][x]}, attempting to load plugin module...')
                # import module[x]
                zcore['plugin'][x] = __import__(zcore['plugin'][x].lower())
                try:
                    zcore['plugin'][x].plugin_init_()
                # plugin is not recognized
                except AttributeError:
                    zcore['plugin'][x] = 'err'
                    print(f'[*] ERROR * Plugin module failed to load: Plugin not recognized.')
                # print(f'MNAME: {zcore['plugin'][x].systemdata['mname']}')
                finally:
                    continue
            # ------------------------------------------------------------------------------------------------------
            # file does not exist
            else:
                print(f'[*] ERROR * Plugin module failed to load: Unable to locate plugin module {zcore['plugin'][x]}.')
                zcore['plugin'][x] = 'err'
                continue
        # --------------------------------------------------------------------------------------------------------------
        # determine mode
        # if zcore['system'] != '0':
        #    zcore['mode'] = 'mod'
        #    print(f'[*] Running in modified system mode.')
        # else:
        #     zcore['mode'] = 'plugin'
        #    print(f'[*] Running in plugin mode.')
# <-- End plugin_load_() ===============================================================================================


# ======================================================================================================================
# Let's get booted up
asyncio.run(start_up())
# End <-- zcore v0.1x by Neo Nemesis [Mode60] =========================================================================